package cl.desafiolatam.desafociclobike

class Ciclovia internal constructor(var nombre: String, var comuna: String)